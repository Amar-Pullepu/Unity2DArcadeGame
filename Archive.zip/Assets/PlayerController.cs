﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class PlayerController : MonoBehaviour {
	private Animator anim;
	public float speed,jumpforce;
	bool grounded;
	static int Score=0,Lives=3;
	public Text MyScore,MyLives;
	public Transform groundCheck;
	public GameObject GameOverPanel;
	// Use this for initialization
	void Start () {
		GameOverPanel.gameObject.SetActive (false);
		anim = gameObject.GetComponent<Animator> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (Lives == 0) {
			GameOverPanel.gameObject.SetActive (true);
			gameObject.SetActive (false);
		}
		if (Input.GetKey (KeyCode.RightArrow)) {
			transform.eulerAngles = new Vector3 (0, 0, 0);
			anim.Play ("WALKANIM");
			gameObject.GetComponent<Rigidbody2D> ().velocity = new Vector2 (speed, gameObject.GetComponent<Rigidbody2D> ().velocity.y);
		} else if (Input.GetKey (KeyCode.LeftArrow)) {
			transform.eulerAngles = new Vector3 (0, 180, 0);
			anim.Play ("WALKANIM");
			gameObject.GetComponent<Rigidbody2D> ().velocity = new Vector2 (-speed, gameObject.GetComponent<Rigidbody2D> ().velocity.y);

		} else if (Input.GetKey (KeyCode.Space) && grounded ) {
			grounded = false;
			anim.Play ("JUMPANIM");
			gameObject.GetComponent<Rigidbody2D> ().AddForce (new Vector3 (0, jumpforce, 0));
		} 
	}
	void OnCollisionEnter2D(Collision2D col) {
		if (col.gameObject.tag == "Bord") {
			GameOverPanel.gameObject.SetActive (true);
		} else if (col.gameObject.tag == "Enemy") {
			DecLife ();
		} 
		else if (col.gameObject.tag == "Life") {
			Destroy (col.gameObject);
			IncLife ();
		} 
		else {
			anim.Play ("IDLEANIM");
			grounded = true;
		}

	}
	void OnCollisionStay2D(Collision2D col) {
		grounded = true;
	}
	void OnCollisionExit2D(Collision2D col) {
		grounded = false;
	}
	void IncScore() {
		Score += 1;
		MyScore.text=Score.ToString();
	}
	void DecLife(){
		Debug.Log ("Life Decresed");
		Lives -= 1;
		MyLives.text = Lives.ToString ();
	}
	void IncLife(){
		Lives += 1;
		MyLives.text = Lives.ToString ();
	}
}
