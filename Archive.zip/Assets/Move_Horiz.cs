﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move_Horiz : MonoBehaviour {
	private Vector2 Startpos;
	private Vector3 Offset;
	public float Speed;
	public GameObject Player;
	// Use this for initialization
	void Start () {
		Startpos = transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		Vector2 v = Startpos;
		v.y += (float)(5) * Mathf.Sin (Time.time * Speed);
		transform.position = v;
	}
}
